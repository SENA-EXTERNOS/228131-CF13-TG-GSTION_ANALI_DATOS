function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6rnJ4rW1Hit":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

